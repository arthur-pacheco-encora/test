package databind

type (
	Column    int
	AccountID string
)
