package fees

const (
	AnchorageValidator    = "AnchorageValidator"
	NonAnchorageValidator = "NonAnchorageValidator"
)
