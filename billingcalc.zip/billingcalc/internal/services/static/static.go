package static

import "embed"

//go:embed **
var Files embed.FS
